<?php
class Padronizacao{
  public static function converterinMain($v){
    return strtoupper($v);
  }
}
